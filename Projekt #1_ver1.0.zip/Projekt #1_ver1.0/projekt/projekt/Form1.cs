﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projekt
{
    public partial class Form1 : Form
    {
        public string[] registersTab; // 0 - AH, 1 - AL, 2 - BH, 3 - BL, 4 - CH, 5 - CL, 6 - DH, 7 - DL
        public string[] fullRegistersTab;

        public string[] program;
        public string oneStepOfProgram;
        public CodeLine lineOfCode;
        public List<CodeLine> listOfSteps = new List<CodeLine>();

        public int stepIndex = 0;

        public struct CodeLine
        {
            public int lineNumber;
            public OrderEnum order;
            public Argument arg1;
            public Argument arg2;
            public Int16 liczba;
        }

        public enum OrderEnum
        {
            none = 0,
            mov = 1,
            add = 2,
            sub = 3,
        }

        public enum Argument
        {
            none = 0,
            a = 1,
            b = 2,
            c = 3,
            d = 4,
            number = 5,
        }

        public Form1()
        {
            InitializeComponent();
            registersTab = new string[8];
            fullRegistersTab = new string[4];
            ReadFromRegistersAll();
        }

        public void Compile()
        {
            program = kodTextBox.Lines;
            
            for (int i = 0; i < program.Length; i++)
            {
                lineOfCode = new CodeLine();
                oneStepOfProgram = program[i];

                string tempString;

                tempString = oneStepOfProgram.Substring(0, 3);

                //==================================== POBRANIE NUMERU LINII

                if (oneStepOfProgram[3] == '.')
                {
                    lineOfCode.lineNumber = int.Parse(tempString);
                }
                else
                {
                    MessageBox.Show("Błąd w składni: Zły numer linii (linia " + (i + 1) + ")");
                    ResetVariables(ref i, ref tempString);
                    return;
                }

                //==================================== POBRANIE ROZKAZU

                tempString = oneStepOfProgram.Substring(5, 3);

                if (tempString == "MOV") lineOfCode.order = OrderEnum.mov;
                else if (tempString == "ADD") lineOfCode.order = OrderEnum.add;
                else if (tempString == "SUB") lineOfCode.order = OrderEnum.sub;
                else
                {
                    MessageBox.Show("Błąd w składni: Zły rozkaz (linia " + (i + 1) + ")");
                    ResetVariables(ref i, ref tempString);
                    return;
                }

                //==================================== POBRANIE ARGUMENTU 1

                tempString = oneStepOfProgram.Substring(9, 1);

                if (tempString == "A") lineOfCode.arg1 = Argument.a;
                else if (tempString == "B") lineOfCode.arg1 = Argument.b;
                else if (tempString == "C") lineOfCode.arg1 = Argument.c;
                else if (tempString == "D") lineOfCode.arg1 = Argument.d;
                else
                {
                    MessageBox.Show("Błąd w składni: Niepoprawny argument 1 (linia " + (i + 1) + ")");
                    ResetVariables(ref i, ref tempString);
                    return;
                }

                //==================================== POBRANIE ARGUMENTU 2

                tempString = oneStepOfProgram.Substring(12);

                if (tempString == "A") lineOfCode.arg2 = Argument.a;
                else if (tempString == "B") lineOfCode.arg2 = Argument.b;
                else if (tempString == "C") lineOfCode.arg2 = Argument.c;
                else if (tempString == "D") lineOfCode.arg2 = Argument.d;
                else if (tempString[0] == '#')
                {
                    lineOfCode.arg2 = Argument.number;
                    tempString = tempString.Substring(1, tempString.Length - 1);
                    lineOfCode.liczba = Int16.Parse(tempString);
                }
                else
                {
                    MessageBox.Show("Błąd w składni: Niepoprawny argument 2 (linia " + (i + 1) + ")");
                    ResetVariables(ref i, ref tempString);
                    return;
                }

                listOfSteps.Add(lineOfCode);
            }
        }

        public void Launch()
        {
            for(int i = 0; i < listOfSteps.Count; i++)
            {
                switch(listOfSteps[i].order)
                {
                    case OrderEnum.mov:
                        MoveData(listOfSteps[i].arg1, listOfSteps[i].arg2, i);
                        break;
                    case OrderEnum.add:
                        AddData(listOfSteps[i].arg1, listOfSteps[i].arg2, i);
                        break;
                    case OrderEnum.sub:
                        AddData(listOfSteps[i].arg1, listOfSteps[i].arg2, i);
                        break;
                    default:
                        MessageBox.Show("Błędny rozkaz");
                        break;
                }
            }
        }

        public void StepLaunch(int index)
        {
            
            if (index < listOfSteps.Count)
            {
                switch (listOfSteps[index].order)
                {
                    case OrderEnum.mov:
                        MoveData(listOfSteps[index].arg1, listOfSteps[index].arg2, index);
                        break;
                    case OrderEnum.add:
                        AddData(listOfSteps[index].arg1, listOfSteps[index].arg2, index);
                        break;
                    case OrderEnum.sub:
                        AddData(listOfSteps[index].arg1, listOfSteps[index].arg2, index);
                        break;
                    default:
                        MessageBox.Show("Błędny rozkaz");
                        break;
                }
            }
        }

        private void MoveData(Argument arg1, Argument arg2, int index)
        {
            string registerHigh;
            string registerLow;
            switch (arg2)
            {
                case Argument.a:
                    registerHigh = registerAH.Text;
                    registerLow = registerAL.Text;
                    WriteRegisterData(registerHigh, registerLow, arg1);
                    break;
                case Argument.b:
                    registerHigh = registerBH.Text;
                    registerLow = registerBL.Text;
                    WriteRegisterData(registerHigh, registerLow, arg1);
                    break;
                case Argument.c:
                    registerHigh = registerCH.Text;
                    registerLow = registerCL.Text;
                    WriteRegisterData(registerHigh, registerLow, arg1);
                    break;
                case Argument.d:
                    registerHigh = registerDH.Text;
                    registerLow = registerDL.Text;
                    WriteRegisterData(registerHigh, registerLow, arg1);
                    break;
                case Argument.number:
                    int liczba = listOfSteps[index].liczba;
                    WriteToRegister(arg1, index, liczba);
                    break;
                default:
                    MessageBox.Show("Błędny argument");
                    break;
            }
        }

        public void AddData(Argument arg1, Argument arg2, int index)                // ADD i SUB
        {
            Int32 liczba1;
            Int32 liczba2;

            switch(arg1)
            {
                case Argument.a:
                    liczba1 = Convert.ToInt32((registerAH.Text + registerAL.Text), 2);
                    break;
                case Argument.b:
                    liczba1 = Convert.ToInt32((registerBH.Text + registerBL.Text), 2);
                    break;
                case Argument.c:
                    liczba1 = Convert.ToInt32((registerCH.Text + registerCL.Text), 2);
                    break;
                case Argument.d:
                    liczba1 = Convert.ToInt32((registerDH.Text + registerDL.Text), 2);
                    break;
                default:
                    liczba1 = 0;
                    break;
            }

            switch (arg2)
            {
                case Argument.a:
                    liczba2 = Convert.ToInt32((registerAH.Text + registerAL.Text), 2);
                    break;
                case Argument.b:
                    liczba2 = Convert.ToInt32((registerBH.Text + registerBL.Text), 2);
                    break;
                case Argument.c:
                    liczba2 = Convert.ToInt32((registerCH.Text + registerCL.Text), 2);
                    break;
                case Argument.d:
                    liczba2 = Convert.ToInt32((registerDH.Text + registerDL.Text), 2);
                    break;
                case Argument.number:
                    liczba2 = listOfSteps[index].liczba;
                    break;
                default:
                    liczba2 = 0;
                    break;
            }

            int wynik = 0;

            if(listOfSteps[index].order == OrderEnum.add)
            {
                wynik = liczba1 + liczba2;
            }
            else
            {
                wynik = liczba1 - liczba2;
            }
             

            WriteToRegister(arg1, index, wynik);
        }

        private void WriteRegisterData(string binaryHigh, string binaryLow, Argument register)
        {
            if (register == Argument.a)
            {
                registerAH.Text = binaryHigh;
                registerAL.Text = binaryLow;
            }
            else if (register == Argument.b)
            {
                registerBH.Text = binaryHigh;
                registerBL.Text = binaryLow;
            }
            else if (register == Argument.c)
            {
                registerCH.Text = binaryHigh;
                registerCL.Text = binaryLow;
            }
            else
            {
                registerDH.Text = binaryHigh;
                registerDL.Text = binaryLow;
            }
        }

        public void ResetVariables(ref int i, ref string tempString)
        {
            i = 0;
            tempString = "";
            listOfSteps.Clear();
        }

        public void ReadFromRegistersAll()
        {
            registersTab[0] = registerAH.Text;
            registersTab[1] = registerAL.Text;
            registersTab[2] = registerBH.Text;
            registersTab[3] = registerBL.Text;
            registersTab[4] = registerCH.Text;
            registersTab[5] = registerCL.Text;
            registersTab[6] = registerDH.Text;
            registersTab[7] = registerDL.Text;

            fullRegistersTab[0] = "";
            fullRegistersTab[0] = fullRegistersTab[0].Insert(0, registersTab[0]);
            fullRegistersTab[0] = fullRegistersTab[0].Insert(8, registersTab[1]);

            fullRegistersTab[1] = "";
            fullRegistersTab[1] = fullRegistersTab[1].Insert(0, registersTab[2]);
            fullRegistersTab[1] = fullRegistersTab[1].Insert(8, registersTab[3]);

            fullRegistersTab[2] = "";
            fullRegistersTab[2] = fullRegistersTab[2].Insert(0, registersTab[4]);
            fullRegistersTab[2] = fullRegistersTab[2].Insert(8, registersTab[5]);

            fullRegistersTab[3] = "";
            fullRegistersTab[3] = fullRegistersTab[3].Insert(0, registersTab[6]);
            fullRegistersTab[3] = fullRegistersTab[3].Insert(8, registersTab[7]);
        }

        public void WriteToRegister(Argument arg1, int index, int liczba)
        {
            Int16 valueToWrite = (Int16)liczba;
            string valueBin = Convert.ToString(valueToWrite, 2);
            string valueBinLow = "";
            string valueBinHigh = "";

            if (valueBin.Length > 8 && valueBin.Length <= 16)
            {
                valueBinLow = valueBin.Substring(valueBin.Length - 8, 8);
                valueBinHigh = valueBin.Substring(0, valueBin.Length - 8);

                for (int i = 0; i < 8 - (valueBin.Length - 8); i++)
                {
                    valueBinHigh = valueBinHigh.Insert(0, "0");
                }
            }
            else if(valueBin.Length > 0 && valueBin.Length <= 8)
            {
                valueBinHigh = "00000000";
                valueBinLow = valueBin;

                for (int i = 0; i < 8 - valueBin.Length; i++)
                {
                    valueBinLow = valueBinLow.Insert(0, "0");
                }
            }

            switch(arg1)
            {
                case Argument.a:
                    registerAH.Text = valueBinHigh;
                    registerAL.Text = valueBinLow;
                    break;
                case Argument.b:
                    registerBH.Text = valueBinHigh;
                    registerBL.Text = valueBinLow;
                    break;
                case Argument.c:
                    registerCH.Text = valueBinHigh;
                    registerCL.Text = valueBinLow;
                    break;
                case Argument.d:
                    registerDH.Text = valueBinHigh;
                    registerDL.Text = valueBinLow;
                    break;
            }

            ReadFromRegistersAll();
        }

        public void ResetRegisters()
        {
            registerAH.Text = "00000000";
            registerAL.Text = "00000000";
            registerBH.Text = "00000000";
            registerBL.Text = "00000000";
            registerCH.Text = "00000000";
            registerCL.Text = "00000000";
            registerDH.Text = "00000000";
            registerDL.Text = "00000000";
        }

        public void ResetWindow()
        {
            kodTextBox.Clear();
        }

        private void trybNormalnyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Compile();
            Launch();
        }

        private void trybKrokowyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void następnyKrokToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (stepIndex < program.Length)
            {
                if (stepIndex == 0)
                {
                    Compile();
                }
                if (stepIndex > 0)
                {
                    kodTextBox.Select(kodTextBox.GetFirstCharIndexFromLine(stepIndex - 1), program[stepIndex - 1].Length);
                    kodTextBox.SelectionColor = Color.Black;
                    kodTextBox.DeselectAll();
                }
                kodTextBox.Select(kodTextBox.GetFirstCharIndexFromLine(stepIndex), program[stepIndex].Length);
                kodTextBox.SelectionColor = Color.Red;
                kodTextBox.DeselectAll();
                StepLaunch(stepIndex);
                stepIndex++;
            }
        }

        private void zatrzymajToolStripMenuItem_Click(object sender, EventArgs e)
        {
            stepIndex = 0;
            kodTextBox.SelectAll();
            kodTextBox.SelectionColor = Color.Black;
            kodTextBox.DeselectAll();
            ResetRegisters();
        }

        private void zapiszToolStripMenuItem_Click(object sender, EventArgs e)
        {
            program = kodTextBox.Lines;

            System.IO.StreamWriter file = new System.IO.StreamWriter("program.txt");

            for(int i = 0; i < program.Length; i++)
            {
                file.WriteLine(program[i]);
            }

            file.Close();
        }

        private void otwórzToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.IO.StreamReader reader = new System.IO.StreamReader("program.txt");

            string line;
            List<string> lines = new List<string>();

            while((line = reader.ReadLine()) != null)
            {
                lines.Add(line);
            }

            program = lines.ToArray();
            kodTextBox.Lines = program;
        }

        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetRegisters();
        }

        private void nowyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResetRegisters();
            ResetWindow();
        }
    }
}
