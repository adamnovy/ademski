﻿namespace projekt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.plikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nowyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zapiszToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otwórzToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zakończToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kompilujIUruchomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trybNormalnyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trybKrokowyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.registerAH = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.registerAL = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.registerBL = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.registerBH = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.registerCL = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.registerCH = new System.Windows.Forms.TextBox();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.registerDL = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.registerDH = new System.Windows.Forms.TextBox();
            this.następnyKrokToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zatrzymajToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kodTextBox = new System.Windows.Forms.RichTextBox();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.plikToolStripMenuItem,
            this.kompilujIUruchomToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(742, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // plikToolStripMenuItem
            // 
            this.plikToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nowyToolStripMenuItem,
            this.resetToolStripMenuItem,
            this.zapiszToolStripMenuItem,
            this.otwórzToolStripMenuItem,
            this.zakończToolStripMenuItem});
            this.plikToolStripMenuItem.Name = "plikToolStripMenuItem";
            this.plikToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.plikToolStripMenuItem.Text = "Plik";
            // 
            // nowyToolStripMenuItem
            // 
            this.nowyToolStripMenuItem.Name = "nowyToolStripMenuItem";
            this.nowyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.nowyToolStripMenuItem.Text = "Nowy";
            this.nowyToolStripMenuItem.Click += new System.EventHandler(this.nowyToolStripMenuItem_Click);
            // 
            // zapiszToolStripMenuItem
            // 
            this.zapiszToolStripMenuItem.Name = "zapiszToolStripMenuItem";
            this.zapiszToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.zapiszToolStripMenuItem.Text = "Zapisz";
            this.zapiszToolStripMenuItem.Click += new System.EventHandler(this.zapiszToolStripMenuItem_Click);
            // 
            // otwórzToolStripMenuItem
            // 
            this.otwórzToolStripMenuItem.Name = "otwórzToolStripMenuItem";
            this.otwórzToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.otwórzToolStripMenuItem.Text = "Otwórz";
            this.otwórzToolStripMenuItem.Click += new System.EventHandler(this.otwórzToolStripMenuItem_Click);
            // 
            // zakończToolStripMenuItem
            // 
            this.zakończToolStripMenuItem.Name = "zakończToolStripMenuItem";
            this.zakończToolStripMenuItem.Size = new System.Drawing.Size(118, 22);
            this.zakończToolStripMenuItem.Text = "Zakończ";
            // 
            // kompilujIUruchomToolStripMenuItem
            // 
            this.kompilujIUruchomToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trybNormalnyToolStripMenuItem,
            this.trybKrokowyToolStripMenuItem});
            this.kompilujIUruchomToolStripMenuItem.Name = "kompilujIUruchomToolStripMenuItem";
            this.kompilujIUruchomToolStripMenuItem.Size = new System.Drawing.Size(126, 20);
            this.kompilujIUruchomToolStripMenuItem.Text = "Kompiluj i Uruchom";
            // 
            // trybNormalnyToolStripMenuItem
            // 
            this.trybNormalnyToolStripMenuItem.Name = "trybNormalnyToolStripMenuItem";
            this.trybNormalnyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.trybNormalnyToolStripMenuItem.Text = "Tryb normalny";
            this.trybNormalnyToolStripMenuItem.Click += new System.EventHandler(this.trybNormalnyToolStripMenuItem_Click);
            // 
            // trybKrokowyToolStripMenuItem
            // 
            this.trybKrokowyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.następnyKrokToolStripMenuItem,
            this.zatrzymajToolStripMenuItem});
            this.trybKrokowyToolStripMenuItem.Name = "trybKrokowyToolStripMenuItem";
            this.trybKrokowyToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.trybKrokowyToolStripMenuItem.Text = "Tryb krokowy";
            this.trybKrokowyToolStripMenuItem.Click += new System.EventHandler(this.trybKrokowyToolStripMenuItem_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.registerAH);
            this.groupBox1.Location = new System.Drawing.Point(390, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(170, 51);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "AH";
            // 
            // registerAH
            // 
            this.registerAH.Location = new System.Drawing.Point(7, 20);
            this.registerAH.Name = "registerAH";
            this.registerAH.Size = new System.Drawing.Size(157, 20);
            this.registerAH.TabIndex = 0;
            this.registerAH.Text = "00000000";
            this.registerAH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.registerAL);
            this.groupBox2.Location = new System.Drawing.Point(566, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(164, 51);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "AL";
            // 
            // registerAL
            // 
            this.registerAL.Location = new System.Drawing.Point(7, 20);
            this.registerAL.Name = "registerAL";
            this.registerAL.Size = new System.Drawing.Size(151, 20);
            this.registerAL.TabIndex = 0;
            this.registerAL.Text = "00000000";
            this.registerAL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.registerBL);
            this.groupBox3.Location = new System.Drawing.Point(566, 85);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(164, 51);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "BL";
            // 
            // registerBL
            // 
            this.registerBL.Location = new System.Drawing.Point(7, 20);
            this.registerBL.Name = "registerBL";
            this.registerBL.Size = new System.Drawing.Size(151, 20);
            this.registerBL.TabIndex = 0;
            this.registerBL.Text = "00000000";
            this.registerBL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.registerBH);
            this.groupBox4.Location = new System.Drawing.Point(390, 85);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(170, 51);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "BH";
            // 
            // registerBH
            // 
            this.registerBH.Location = new System.Drawing.Point(7, 20);
            this.registerBH.Name = "registerBH";
            this.registerBH.Size = new System.Drawing.Size(157, 20);
            this.registerBH.TabIndex = 0;
            this.registerBH.Text = "00000000";
            this.registerBH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.registerCL);
            this.groupBox5.Location = new System.Drawing.Point(566, 142);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(164, 51);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "CL";
            // 
            // registerCL
            // 
            this.registerCL.Location = new System.Drawing.Point(7, 20);
            this.registerCL.Name = "registerCL";
            this.registerCL.Size = new System.Drawing.Size(151, 20);
            this.registerCL.TabIndex = 0;
            this.registerCL.Text = "00000000";
            this.registerCL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.registerCH);
            this.groupBox6.Location = new System.Drawing.Point(390, 142);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(170, 51);
            this.groupBox6.TabIndex = 12;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "CH";
            // 
            // registerCH
            // 
            this.registerCH.Location = new System.Drawing.Point(7, 20);
            this.registerCH.Name = "registerCH";
            this.registerCH.Size = new System.Drawing.Size(157, 20);
            this.registerCH.TabIndex = 0;
            this.registerCH.Text = "00000000";
            this.registerCH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.registerDL);
            this.groupBox.Location = new System.Drawing.Point(566, 199);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(164, 51);
            this.groupBox.TabIndex = 13;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "DL";
            // 
            // registerDL
            // 
            this.registerDL.Location = new System.Drawing.Point(7, 20);
            this.registerDL.Name = "registerDL";
            this.registerDL.Size = new System.Drawing.Size(151, 20);
            this.registerDL.TabIndex = 0;
            this.registerDL.Text = "00000000";
            this.registerDL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.registerDH);
            this.groupBox8.Location = new System.Drawing.Point(390, 199);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(170, 51);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "DH";
            // 
            // registerDH
            // 
            this.registerDH.Location = new System.Drawing.Point(7, 20);
            this.registerDH.Name = "registerDH";
            this.registerDH.Size = new System.Drawing.Size(157, 20);
            this.registerDH.TabIndex = 0;
            this.registerDH.Text = "00000000";
            this.registerDH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // następnyKrokToolStripMenuItem
            // 
            this.następnyKrokToolStripMenuItem.Name = "następnyKrokToolStripMenuItem";
            this.następnyKrokToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.następnyKrokToolStripMenuItem.Text = "Następny krok";
            this.następnyKrokToolStripMenuItem.Click += new System.EventHandler(this.następnyKrokToolStripMenuItem_Click);
            // 
            // zatrzymajToolStripMenuItem
            // 
            this.zatrzymajToolStripMenuItem.Name = "zatrzymajToolStripMenuItem";
            this.zatrzymajToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.zatrzymajToolStripMenuItem.Text = "Zatrzymaj";
            this.zatrzymajToolStripMenuItem.Click += new System.EventHandler(this.zatrzymajToolStripMenuItem_Click);
            // 
            // kodTextBox
            // 
            this.kodTextBox.Location = new System.Drawing.Point(13, 28);
            this.kodTextBox.Name = "kodTextBox";
            this.kodTextBox.Size = new System.Drawing.Size(371, 222);
            this.kodTextBox.TabIndex = 14;
            this.kodTextBox.Text = "";
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 257);
            this.Controls.Add(this.kodTextBox);
            this.Controls.Add(this.groupBox);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem plikToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nowyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zapiszToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otwórzToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zakończToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kompilujIUruchomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trybNormalnyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trybKrokowyToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox registerAH;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox registerAL;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox registerBL;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox registerBH;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox registerCL;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox registerCH;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.TextBox registerDL;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox registerDH;
        private System.Windows.Forms.ToolStripMenuItem następnyKrokToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zatrzymajToolStripMenuItem;
        private System.Windows.Forms.RichTextBox kodTextBox;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
    }
}

